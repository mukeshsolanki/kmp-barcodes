/*
 * Copyright 2013 ZXing authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Ported to Kotlin from zxing 3.5.3 for kmp-barcodes.

package com.mukeshsolanki.barcodes.internal.zxing.qrcode.decoder

import com.mukeshsolanki.barcodes.internal.zxing.ResultPoint

/**
 * QR decoding metadata passed back through DecoderResult.other.
 */
internal class QRCodeDecoderMetaData(
    /** True if the QR Code was mirrored. */
    val isMirrored: Boolean,
) {
    /** Swaps the bottom-left and top-right points in [points] when the code was mirrored. */
    fun applyMirroredCorrection(points: Array<ResultPoint>?) {
        if (!isMirrored || points == null || points.size < 3) {
            return
        }
        val bottomLeft = points[0]
        points[0] = points[2]
        points[2] = bottomLeft
    }
}
